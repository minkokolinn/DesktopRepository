insert into keyword_tbl values (1,'using','Red')
insert into keyword_tbl values (2,'public','Red')
insert into keyword_tbl values (3,'private','Red')
insert into keyword_tbl values (4,'protected','Red')
insert into keyword_tbl values (5,'namespace','Red')
insert into keyword_tbl values (6,'void','Red')
insert into keyword_tbl values (7,'return','Red')

insert into keyword_tbl values (8,'string','LightBlue')
insert into keyword_tbl values (9,'int','LightBlue')
insert into keyword_tbl values (10,'float','LightBlue')
insert into keyword_tbl values (11,'double','LightBlue')
insert into keyword_tbl values (12,'Boolean','LightBlue')
insert into keyword_tbl values (13,'char','LightBlue')

insert into keyword_tbl values (14,'object','Yellow')
insert into keyword_tbl values (15,'new','Yellow')
insert into keyword_tbl values (16,'if','Yellow')
insert into keyword_tbl values (17,'else','Yellow')
insert into keyword_tbl values (18,'try','Yellow')
insert into keyword_tbl values (19,'catch','Yellow')
insert into keyword_tbl values (20,'static','Yellow')

select * from keyword_tbl