package controller.transfer;

import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class TransferSlider {
    @FXML
    private VBox TransferSlide;

}
