package controller.donation;

import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class DonateSlider {
    @FXML
    private VBox DonateSlide;
}
