package controller.admin;

import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class SliderController {
    @FXML
    private VBox slide;
}
